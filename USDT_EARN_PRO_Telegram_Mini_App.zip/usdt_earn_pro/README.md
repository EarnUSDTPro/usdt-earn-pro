# USDT EARN PRO — Telegram Mini App starter

This project contains a responsive Telegram Mini App UI inspired by your screenshots:
- Home dashboard and demo balance
- Missions and simulated task rewards
- Referral link display/share
- Wallet screen and local demo withdrawal requests
- Telegram Web Apps SDK integration
- Example server-side Telegram `initData` verification

## Important: demo vs real money
This starter is a working **front-end demo**. Demo balances, task rewards, referral counts and withdrawal requests are stored in the browser's local storage only. They are not real USDT, cannot be withdrawn, and are not shared between users. The ad button does not pay rewards.

Before accepting users or advertising real payouts, build and audit a backend that:
1. Verifies Telegram `initData` on every authenticated API request.
2. Stores users, tasks, task proofs, referrals, balances and withdrawal requests in a database.
3. Verifies channel membership server-side using a Telegram bot with the necessary channel permissions.
4. Uses a trusted ad network's server-side reward callbacks; never credit on a button click.
5. Enforces anti-fraud limits and an admin approval process.
6. Sends BEP-20 USDT only from a secured, funded payout service. Never collect seed phrases or private keys from users.

## Run locally
Requires Node.js 18+.

```bash
npm install
BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN" npm start
```

Open `http://localhost:3000` for the preview. The demo UI can be previewed without a bot token; `/api/auth` requires a real token and valid Telegram `initData`.

## Deploy with Render (HTTPS)
1. Push this project to a GitHub repository.
2. In Render, choose **New → Blueprint** and select that repository; Render reads `render.yaml`.
3. Add `BOT_TOKEN` as a secret environment variable in the Render service settings. Never put it in frontend files or commit it.
4. Deploy. Render provides an `https://...onrender.com` URL and manages TLS certificates.
5. Open `/api/health` on that URL and confirm it returns `ok: true`.
6. Set the HTTPS URL as the Mini App URL in BotFather.

The Render free service may sleep when idle; first load can be slow. Check the current Render plan limits before relying on it for production.

## Connect to Telegram
1. Deploy this app to an HTTPS host.
2. Create/manage your bot with **@BotFather**.
3. Set the deployed HTTPS URL as the Mini App URL in BotFather.
4. The project is preconfigured for **@EarnUSDTProBot** in `public/app.js`.
5. Set `BOT_TOKEN` as a server environment variable. Do not put it in frontend code.
6. Add the server API/database flows before enabling real balances, task verification or payouts.

## Files
- `public/index.html` — app structure
- `public/styles.css` — responsive dark green/teal theme
- `public/app.js` — demo interactions
- `server.js` — Express server and Telegram initData verification example

This is a starter, not a complete audited financial or payout system.
