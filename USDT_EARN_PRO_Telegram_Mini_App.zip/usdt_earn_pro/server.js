// Minimal production-oriented Telegram initData verification example.
// Add persistent database, rate limits, admin authorization and payout review before launch.
const express=require('express'),crypto=require('crypto'),path=require('path');
const app=express();app.use(express.json());app.use(express.static(path.join(__dirname,'public')));
const BOT_TOKEN=process.env.BOT_TOKEN;
function verifyInitData(initData){
 if(!BOT_TOKEN||!initData) return null;
 const p=new URLSearchParams(initData),hash=p.get('hash');if(!hash)return null;p.delete('hash');
 const data=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
 const secret=crypto.createHmac('sha256','WebAppData').update(BOT_TOKEN).digest();
 const expected=crypto.createHmac('sha256',secret).update(data).digest('hex');
 const a=Buffer.from(hash,'hex'),b=Buffer.from(expected,'hex');
 if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;
 const authDate=Number(p.get('auth_date'));if(!authDate||Date.now()/1000-authDate>86400)return null;
 try{return JSON.parse(p.get('user')||'{}')}catch{return null}
}
app.post('/api/auth',(req,res)=>{const user=verifyInitData(req.body.initData);if(!user)return res.status(401).json({error:'Invalid Telegram session'});res.json({ok:true,user:{id:user.id,first_name:user.first_name,username:user.username}})});
app.get('/api/health',(_,res)=>res.json({ok:true,app:'USDT EARN PRO',mode:'starter'}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`USDT EARN PRO running on ${port}`));